import java.util.*;

public class Float {
    public static void main(String[] args)  {
        Field f = new Field(50,25);

        Star bob = new Star(0,0,0,0);

        Random r = new Random();
        Star[] stars = new Star[10];
        for (int i=0; i<stars.length; i++) 
            stars[i] = new Star(r.nextDouble()*f.getMaxX(),r.nextDouble()*f.getMaxY(),r.nextDouble()-0.5,r.nextDouble()-0.5);
        
        while (true) {
            // draw another animation frame
            f.blank();
            for (int i=0; i<stars.length; i++)
                f.draw(stars[i].getX(),stars[i].getY(),'*');
            f.show();
            System.out.print(Star.getCount());

            // update all the stars
            for (int i=0; i<stars.length; i++) 
                stars[i].move(f.getMaxX(),f.getMaxY());
        }
    }
}